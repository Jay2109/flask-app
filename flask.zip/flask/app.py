from flask import Flask,render_template,request,url_for,redirect
from iexfinance.stocks import Stock
from iexfinance.stocks import get_historical_data
from datetime import datetime
from datetime import date
from iexfinance.stocks import get_historical_intraday
from iexfinance.altdata import get_social_sentiment
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
import pandas_datareader as web
import numpy as np



def stock_details(sym):
    accstoken="pk_37daafb6ee424bb2b3cb03285396efd3"
    #sym="MSFT"
    date_=date.today()
    stock = Stock(sym,token=accstoken)
    quote=stock.get_quote()
    balance=stock.get_balance_sheet(token=accstoken)
    get_price=stock.get_price()
    history_intraday=get_historical_intraday(sym, date_,token=accstoken)
    price_target=stock.get_price_target()
    social_sentiment=get_social_sentiment(sym,token=accstoken)
    return quote,get_price,social_sentiment

def predict(sym):
    new_model = tf.keras.models.load_model('stocks.h5')
    new_model.summary()
    end_date=date.today()
    #Get the quote
    apple_quote = web.DataReader(sym, data_source='yahoo', start='2019-11-01', end=end_date)
    #Create a new dataframe
    new_df = apple_quote.filter(['Close'])#Get the last 60 day closing price 
    last_60_days = new_df[-60:].values
    #Scale the data to be values between 0 and 1    
    scaler = MinMaxScaler(feature_range=(0, 1)) 
    last_60_days_scaled = scaler.fit_transform(last_60_days)
    X_test = []#Append teh past 60 days
    X_test.append(last_60_days_scaled)#Convert the X_test data set to a numpy array
    X_test = np.array(X_test)#Reshape the data
    X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))#Get the predicted scaled price
    pred_price =new_model.predict(X_test)#undo the scaling 
    pred_price = scaler.inverse_transform(pred_price)
    return pred_price


from flask import Flask, redirect, url_for, render_template, request

app = Flask(__name__)

@app.route("/", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        user = request.form["stock_name"]
        return redirect(url_for("user", usr=user))
    else:
        return render_template("index.html")

@app.route("/<usr>")
def user(usr):
    quote,price,social=stock_details(usr)
    pred=predict(usr)
    return render_template("result.html",quote=quote,price=price,social=social,predict=pred,social_sent=social)

if __name__ == "__main__":
    app.run(debug=True)